package com.lucian.tiendaordenador.setup;

import java.io.IOException;
import java.net.URL;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.lucian.tiendaordenador.model.Carrito;
import com.lucian.tiendaordenador.model.Categoria;
import com.lucian.tiendaordenador.model.Ordenador;
import com.lucian.tiendaordenador.model.Usuario;
import com.lucian.tiendaordenador.servicios.ServicioOrdenadores;
import com.lucian.tiendaordenador.servicios.servicioPedidos;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@Component
@Transactional
public class SetUpImpl implements SetUp {

    @Autowired
    private servicioPedidos servicioPedidos;

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public void prepararRegistros() {
        TablaSetUp registroSetUp = null;
        
        //preparar los registros iniciales
        try {
            registroSetUp = entityManager.createQuery("SELECT r FROM TablaSetUp r", TablaSetUp.class).getSingleResult();
        } catch (Exception e) {
            System.out.println("No se encontró ningún registro en la tabla SetUp, se procederá con la inicialización.");
        }

        if (registroSetUp != null && registroSetUp.isCompletado()) {
            return;
        }
        
        //preparar categorias iniciales
        Categoria cGaming = new Categoria("Gaming", "Ordenador Gaming");
        entityManager.persist(cGaming);
        Categoria cSobreMesa = new Categoria("SobreMesa", "Ordenador de SobreMesa");
        entityManager.persist(cSobreMesa);
        Categoria cPortatil = new Categoria("Portatil", "Ordenador Portátil");
        entityManager.persist(cPortatil);
        		

        // Crear usuarios
        Usuario usuario1 = new Usuario("Carlos", "Ramírez", "600123456", "pass123", "carlos@tienda.com");
        Usuario usuario2 = new Usuario("Lucía", "Martínez", "611234567", "lucia456", "lucia@tienda.com");
        Usuario usuario3 = new Usuario("Miguel", "Gómez", "622345678", "miguel789", "miguel@tienda.com");
        Usuario usuario4 = new Usuario("Sofía", "López", "633456789", "sofiaabc", "sofia@tienda.com");
        Usuario usuario5 = new Usuario("David", "Fernández", "644567890", "davidxyz", "david@tienda.com");
        Usuario usuario6 = new Usuario("Ana", "Torres", "655678901", "ana321", "ana@tienda.com");
        Usuario usuario7 = new Usuario("Lucian", "Simion", "643072931", "1234", "simionlucianandrei0@gmail.com");

        entityManager.persist(usuario1);
        entityManager.persist(usuario2);
        entityManager.persist(usuario3);
        entityManager.persist(usuario4);
        entityManager.persist(usuario5);
        entityManager.persist(usuario6);
        entityManager.persist(usuario7);

        // Crear ordenadores
        Ordenador ordenador1 = new Ordenador();
        ordenador1.setNombre("Ordenador Gaming Pro");
        ordenador1.setCpu("AMD Ryzen 7 5800X");
        ordenador1.setGpu("NVIDIA RTX 3070");
        ordenador1.setPlaca("ASUS ROG Strix B550-F");
        ordenador1.setPrecio(1200.23);
        ordenador1.setPcu("Corsair RM750x");
        ordenador1.setRam("16GB DDR4");
        ordenador1.setCaja("NZXT H510");
        ordenador1.setMemoria("1TB NVMe SSD");
        ordenador1.setExtras("Refrigeración líquida, RGB");
        ordenador1.setDescripcion("Equipo de alto rendimiento para gaming y tareas exigentes");
        ordenador1.setCategoria(cGaming);
        ordenador1.setImagenPortada(obtenerInfoImagen("http://localhost:8080/imagenes_base/ordenadores/ordenador1.jpg"));
        entityManager.persist(ordenador1);

        Ordenador ordenador2 = new Ordenador();
        ordenador2.setNombre("Ordenador Oficina Básico");
        ordenador2.setCpu("Intel Core i3");
        ordenador2.setGpu("Integrada Intel UHD");
        ordenador2.setPlaca("MSI H510M-A");
        ordenador2.setPrecio(1200.23);
        ordenador2.setPcu("Be Quiet 500W");
        ordenador2.setRam("8GB DDR4");
        ordenador2.setCaja("Mini Tower");
        ordenador2.setMemoria("256GB SSD");
        ordenador2.setExtras("Wi-Fi integrado");
        ordenador2.setDescripcion("Ideal para tareas de oficina y navegación");
        ordenador2.setCategoria(cSobreMesa);
        ordenador2.setImagenPortada(obtenerInfoImagen("http://localhost:8080/imagenes_base/ordenadores/ordenador2.jpg"));
        entityManager.persist(ordenador2);

        Carrito carrito1 = new Carrito();
        carrito1.setUsuario(usuario1);
        carrito1.setOrdenador(ordenador1);
        carrito1.setCantidad(3);
        entityManager.persist(carrito1);
        
        //registrar un pedido para usuario1
        servicioPedidos.procesarPaso1("Lucian", "Calle Ofelia Nieto", "Madrid","643072931", "28039", "simionlucianandrei0@gmail.com", usuario1.getId());
        servicioPedidos.procesarPaso2("1", "0231 2302 1321 1231", "Lucian", usuario1.getId());
        servicioPedidos.confirmarPedido(usuario1.getId());

        Carrito carrito2 = new Carrito();
        carrito2.setUsuario(usuario3);
        carrito2.setOrdenador(ordenador2);
        carrito2.setCantidad(2);
        entityManager.persist(carrito2);

        TablaSetUp nuevoRegistro = new TablaSetUp();
        nuevoRegistro.setCompletado(true);
        entityManager.persist(nuevoRegistro);
    }

    private byte[] obtenerInfoImagen(String rutaOrigen) {
        byte[] info = null;
        try {
            URL url = new URL(rutaOrigen);
            info = IOUtils.toByteArray(url);
        } catch (IOException e) {
            System.out.println("No se pudo procesar la imagen: " + rutaOrigen);
            e.printStackTrace();
        }
        return info;
    }
}