package com.lucian.tiendaordenador.servicios;

import java.util.List;
import java.util.Map;

import com.lucian.tiendaordenador.model.Ordenador;

public interface ServicioOrdenadores {

	void registrarOrdenador(Ordenador ordenador);

	List<Ordenador> obtenerOrdenadores();

	void borrarOrdenador(long id);

	void actualizarOrdenador(Ordenador ordenador);

	Ordenador obtenerOrdenadorPorId(long id);

	List<Map<String, Object>> obtenerOrdenadoresParaFormarJSON();
	
	// para la parte publica, servicios REST

}
