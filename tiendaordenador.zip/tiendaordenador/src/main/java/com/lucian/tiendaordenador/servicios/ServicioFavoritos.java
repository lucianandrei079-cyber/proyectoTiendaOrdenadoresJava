package com.lucian.tiendaordenador.servicios;

import java.util.List;
import java.util.Map;

public interface ServicioFavoritos {
	void añadirFavorito(int idUsuario, long idProducto);
	
	List<Map<String, Object>> obtenerProductosFavoritos( int idUsuario);

	void quitarProductoFavorito(int idUsuario, Long idOrdenador);
}
