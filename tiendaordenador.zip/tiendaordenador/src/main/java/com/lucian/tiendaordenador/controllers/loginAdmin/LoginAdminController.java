package com.lucian.tiendaordenador.controllers.loginAdmin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.lucian.tiendaordenador.controllers.admin.OrdenadoresController;

import jakarta.servlet.http.HttpServletRequest;


@Controller
public class LoginAdminController {
	
	@Autowired
	private MessageSource messageSource;

    @Autowired
    private OrdenadoresController ordenadoresController;

    @RequestMapping("loginAdmin")
    public String loginAdmin() {
        return "admin/loginAdmin";
    }

    @RequestMapping("logoutAdmin")
    public String logoutAdmin(HttpServletRequest request) {
    	String idiomaActual = 
        		messageSource.getMessage("idioma", null, LocaleContextHolder.getLocale());
        request.getSession().invalidate();
        return "tienda_" + idiomaActual;
    }
}