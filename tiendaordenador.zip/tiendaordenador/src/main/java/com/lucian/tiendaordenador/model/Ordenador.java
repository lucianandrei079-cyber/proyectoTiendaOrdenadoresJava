package com.lucian.tiendaordenador.model;


import java.util.ArrayList;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import io.micrometer.common.lang.NonNull;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Entity
@Table(name="tabla_ordenadores")
public class Ordenador {
	
    @Size(min = 3, max = 50, message = "El nombre debe tener entre 3 y 50 caracteres")
    @NotEmpty(message = "Debes insertar un nombre")
    @Pattern(regexp = "^(?!.* {2})(?! )[A-Za-z0-9 áéíóúÁÉÍÓÚñÑ-]+(?<! )$", 
             message = "El nombre solo puede contener letras, números, guiones y espacios simples")
    private String nombre;

    @Size(min = 3, max = 60, message = "La CPU debe tener entre 3 y 60 caracteres")
    @NotEmpty(message = "Debes insertar una CPU")
    @Pattern(regexp = "^(?!.* {2})(?! )[A-Za-z0-9 áéíóúÁÉÍÓÚñÑ-]+(?<! )$", 
             message = "La CPU solo puede contener letras, números, guiones y espacios simples")
    private String cpu;

    @Size(min = 3, max = 60, message = "La GPU debe tener entre 3 y 60 caracteres")
    @NotEmpty(message = "Debes insertar una GPU")
    @Pattern(regexp = "^(?!.* {2})(?! )[A-Za-z0-9 áéíóúÁÉÍÓÚñÑ-]+(?<! )$", 
             message = "La GPU solo puede contener letras, números, guiones y espacios simples")
    private String gpu;

    @Size(min = 3, max = 70, message = "La placa debe tener entre 3 y 70 caracteres")
    @NotEmpty(message = "Debes insertar una placa")
    @Pattern(regexp = "^(?!.* {2})(?! )[A-Za-z0-9 áéíóúÁÉÍÓÚñÑ-]+(?<! )$", 
             message = "La placa solo puede contener letras, números, guiones y espacios simples")
    private String placa;

    @NotNull(message = "Debes insertar un precio")
    @Min(value = 1, message = "El precio mínimo es de 1 euro")
    @Max(value = 9999, message = "El precio máximo es de 9999 euros")
    private double precio;

    @Size(min = 3, max = 50, message = "El PCU debe tener entre 3 y 50 caracteres")
    @NotEmpty(message = "Debes insertar un PCU")
    @Pattern(regexp = "^(?!.* {2})(?! )[A-Za-z0-9 áéíóúÁÉÍÓÚñÑ-]+(?<! )$", 
             message = "El PCU solo puede contener letras, números, guiones y espacios simples")
    private String pcu;

    @Size(min = 3, max = 50, message = "La RAM debe tener entre 3 y 50 caracteres")
    @NotEmpty(message = "Debes insertar una RAM")
    @Pattern(regexp = "^(?!.* {2})(?! )[A-Za-z0-9 áéíóúÁÉÍÓÚñÑ-]+(?<! )$", 
             message = "La RAM solo puede contener letras, números, guiones y espacios simples")
    private String ram;

    @Size(min = 3, max = 50, message = "La caja debe tener entre 3 y 50 caracteres")
    @NotEmpty(message = "Debes insertar una caja")
    @Pattern(regexp = "^(?!.* {2})(?! )[A-Za-z0-9 áéíóúÁÉÍÓÚñÑ-]+(?<! )$", 
             message = "La caja solo puede contener letras, números, guiones y espacios simples")
    private String caja;

    @Size(min = 3, max = 60, message = "La memoria debe tener entre 3 y 60 caracteres")
    @NotEmpty(message = "Debes insertar una memoria")
    @Pattern(regexp = "^(?!.* {2})(?! )[A-Za-z0-9 áéíóúÁÉÍÓÚñÑ-]+(?<! )$", 
             message = "La memoria solo puede contener letras, números, guiones y espacios simples")
    private String memoria;

    @Size(min = 3, max = 80, message = "Los extras deben tener entre 3 y 80 caracteres")
    @NotEmpty(message = "Debes insertar extras")
    @Pattern(regexp = "^(?!.* {2})(?! )[A-Za-z0-9 áéíóúÁÉÍÓÚñÑ,.!?()-]+(?<! )$", 
             message = "Los extras solo pueden contener letras, números, espacios simples y signos básicos de puntuación")
    private String extras;

    @Size(min = 3, max = 200, message = "La descripción debe tener entre 3 y 200 caracteres")
    @NotEmpty(message = "Debes insertar una descripción")
    @Pattern(regexp = "^(?!.* {2})(?! )[A-Za-z0-9 áéíóúÁÉÍÓÚñÑ,.!?()-]+(?<! )$", 
             message = "La descripción solo puede contener letras, números, espacios simples y signos básicos de puntuación")
    private String descripcion;

	@Lob
	@Column(name = "imagen_portada", columnDefinition = "LONGBLOB")
	private byte[] imagenPortada;

	@Lob
	@Column(name = "imagen_secundaria1", columnDefinition = "LONGBLOB")
	private byte[] imagenSecundaria1;

	@Lob
	@Column(name = "imagen_secundaria2", columnDefinition = "LONGBLOB")
	private byte[] imagenSecundaria2;
	
	@ManyToOne
	@JoinColumn(name = "categoria_id")
	private Categoria categoria;

	@Transient
	private MultipartFile imagen;

	@Transient
	private MultipartFile imagen1;

	@Transient
	private MultipartFile imagen2;
	
	@Transient
	private long idCategoria;
	
	@OneToMany (mappedBy = "ordenador")
	private List<Carrito> carritos = new ArrayList<Carrito>();
	
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	public Ordenador() {
		
	}

	public Ordenador(String nombre, String cpu, String gpu, String placa, String pcu, String ram, String caja,
			String memoria, String extras, String descripcion, long id) {
		super();
		this.nombre = nombre;
		this.cpu = cpu;
		this.gpu = gpu;
		this.placa = placa;
		this.pcu = pcu;
		this.ram = ram;
		this.caja = caja;
		this.memoria = memoria;
		this.extras = extras;
		this.descripcion = descripcion;
		this.id = id;
	}
	
	

	public Ordenador(String nombre, String cpu, String gpu, String placa, double precio, String pcu, String ram,
			String caja, String memoria, String extras, String descripcion, byte[] imagenPortada,
			byte[] imagenSecundaria1, byte[] imagenSecundaria2, MultipartFile imagen, MultipartFile imagen1,
			MultipartFile imagen2, List<Carrito> carritos, long id) {
		super();
		this.nombre = nombre;
		this.cpu = cpu;
		this.gpu = gpu;
		this.placa = placa;
		this.precio = precio;
		this.pcu = pcu;
		this.ram = ram;
		this.caja = caja;
		this.memoria = memoria;
		this.extras = extras;
		this.descripcion = descripcion;
		this.imagenPortada = imagenPortada;
		this.imagenSecundaria1 = imagenSecundaria1;
		this.imagenSecundaria2 = imagenSecundaria2;
		this.imagen = imagen;
		this.imagen1 = imagen1;
		this.imagen2 = imagen2;
		this.carritos = carritos;
		this.id = id;
	}

	public Ordenador(String nombre, String cpu, String gpu, String placa, String pcu, String ram, String caja,
			String memoria, String descripcion, long id) {
		super();
		this.nombre = nombre;
		this.cpu = cpu;
		this.gpu = gpu;
		this.placa = placa;
		this.pcu = pcu;
		this.ram = ram;
		this.caja = caja;
		this.memoria = memoria;
		this.descripcion = descripcion;
		this.id = id;
	}
	
	public long getIdCategoria() {
		return idCategoria;
	}

	public void setIdCategoria(long idCategoria) {
		this.idCategoria = idCategoria;
	}

	public Categoria getCategoria() {
		return categoria;
	}

	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public List<Carrito> getCarritos() {
		return carritos;
	}

	public void setCarritos(List<Carrito> carritos) {
		this.carritos = carritos;
	}

	public byte[] getImagenSecundaria1() {
		return imagenSecundaria1;
	}

	public void setImagenSecundaria1(byte[] imagenSecundaria1) {
		this.imagenSecundaria1 = imagenSecundaria1;
	}

	public byte[] getImagenSecundaria2() {
		return imagenSecundaria2;
	}

	public void setImagenSecundaria2(byte[] imagenSecundaria2) {
		this.imagenSecundaria2 = imagenSecundaria2;
	}

	public MultipartFile getImagen1() {
		return imagen1;
	}

	public void setImagen1(MultipartFile imagen1) {
		this.imagen1 = imagen1;
	}

	public MultipartFile getImagen2() {
		return imagen2;
	}

	public void setImagen2(MultipartFile imagen2) {
		this.imagen2 = imagen2;
	}

	public byte[] getImagenPortada() {
		return imagenPortada;
	}

	public void setImagenPortada(byte[] imagenPortada) {
		this.imagenPortada = imagenPortada;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getCpu() {
		return cpu;
	}

	public void setCpu(String cpu) {
		this.cpu = cpu;
	}

	public String getGpu() {
		return gpu;
	}

	public void setGpu(String gpu) {
		this.gpu = gpu;
	}

	public String getPlaca() {
		return placa;
	}

	public void setPlaca(String placa) {
		this.placa = placa;
	}

	public String getPcu() {
		return pcu;
	}

	public void setPcu(String pcu) {
		this.pcu = pcu;
	}

	public String getRam() {
		return ram;
	}

	public void setRam(String ram) {
		this.ram = ram;
	}

	public String getCaja() {
		return caja;
	}

	public void setCaja(String caja) {
		this.caja = caja;
	}

	public String getMemoria() {
		return memoria;
	}

	public void setMemoria(String memoria) {
		this.memoria = memoria;
	}

	public String getExtras() {
		return extras;
	}

	public void setExtras(String extras) {
		this.extras = extras;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	
	

	public MultipartFile getImagen() {
		return imagen;
	}

	public void setImagen(MultipartFile imagen) {
		this.imagen = imagen;
	}

	@Override
	public String toString() {
		return "Ordenador [nombre=" + nombre + ", cpu=" + cpu + ", gpu=" + gpu + ", placa=" + placa + ", pcu=" + pcu
				+ ", ram=" + ram + ", caja=" + caja + ", memoria=" + memoria + ", extras=" + extras + ", descripcion="
				+ descripcion + ", id=" + id + "]";
	}
	
	
}
