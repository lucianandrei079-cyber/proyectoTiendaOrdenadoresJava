package com.lucian.tiendaordenador.setup;

public interface SetUp {
	void prepararRegistros();
}
