package com.lucian.tiendaordenador.serviciosJPAImpl;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lucian.tiendaordenador.model.Usuario;
import com.lucian.tiendaordenador.servicios.ServicioUsuarios;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@Service
@Transactional
public class ServicioUsuariosImpl implements ServicioUsuarios {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public void registrarUsuario(Usuario usuario) {
        entityManager.persist(usuario);
    }

    @Override
    public List<Usuario> obtenerUsuarios() {
        return entityManager.createQuery("select u from Usuario u", Usuario.class).getResultList();
    }

    @Override
    public void borrarUsuario(int id) {
        Usuario usuarioAborrar = obtenerUsuarioPorId(id);
        if (usuarioAborrar != null) {
            entityManager.remove(usuarioAborrar);
        }
    }

    @Override
    public Usuario obtenerUsuarioPorId(int id) {
        return entityManager.find(Usuario.class, id);
    }

    @Override
    public void actualizarUsuario(Usuario usuarioEditar) {
        entityManager.merge(usuarioEditar);
    }

    @Override
    public Usuario obtenerUsuarioPorEmailYpass(String email, String pass) {
        try {
            return entityManager.createQuery(
                    "select u from Usuario u where u.email = :email and u.pass = :pass", Usuario.class)
                    .setParameter("email", email)
                    .setParameter("pass", pass)
                    .getSingleResult();
        } catch (Exception e) {
            System.out.println("No se encontró un usuario con el email y pass indicado");
            return null;
        }
    }

    @Override
    public Usuario obtenerUsuarioPorEmail(String email) {
        try {
            return entityManager.createQuery(
                    "select u from Usuario u where u.email = :email", Usuario.class)
                    .setParameter("email", email)
                    .getSingleResult();
        } catch (Exception e) {
            System.out.println("No hay usuario con el email indicado");
            return null;
        }
    }
}