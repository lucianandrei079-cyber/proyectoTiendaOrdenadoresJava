package com.lucian.tiendaordenador.constantesSQL;

public class ConstantesSQL {

    public static final String SQL_OBTENER_ORDENADORES_PARA_JSON = "SELECT o.id, o.nombre, o.cpu, o.gpu, o.placa, o.pcu, o.precio, "
            + "o.ram, o.caja, o.memoria, o.extras, o.descripcion, "
            + "c.nombre as nombre_categoria FROM tabla_ordenadores o, categoria c where o.categoria_id = c.id ORDER BY o.id DESC";

    public static final String SQL_OBTENER_PRODUCTOS_CARRITO = "SELECT "
            + "    C.USUARIO_ID, "
            + "    O.NOMBRE, "
            + "    O.ID AS ORDENADOR_ID, "
            + "    O.PRECIO, "
            + "    O.DESCRIPCION, "
            + "    C.CANTIDAD "
            + "FROM CARRITO AS C, TABLA_ORDENADORES AS O "
            + "WHERE "
            + "    C.USUARIO_ID = :usuario_id AND O.ID = C.ORDENADOR_ID";

    public static final String SQL_ELIMINAR_PRODUCTO_CARRITO = "DELETE FROM CARRITO WHERE ORDENADOR_ID = :ordenador_id AND USUARIO_ID = :usuario_id";

    public static final String SQL_VACIAR_CARRITO = "DELETE FROM CARRITO WHERE USUARIO_ID = :usuario_id";

    // FAVORITOS


    public static final String SQL_OBTENER_PRODUCTOS_FAVORITOS = "SELECT "
            + "    F.USUARIO_ID, "
            + "    O.NOMBRE, "
            + "    O.ID AS ORDENADOR_ID, "
            + "    O.PRECIO, "
            + "    O.DESCRIPCION "
            + "FROM FAVORITOS AS F, TABLA_ORDENADORES AS O "
            + "WHERE "
            + "    F.USUARIO_ID = :usuario_id AND O.ID = F.ORDENADOR_ID";

    public static final String SQL_ELIMINAR_PRODUCTO_FAVORITO = "DELETE FROM FAVORITOS WHERE ORDENADOR_ID = :ordenador_id AND USUARIO_ID = :usuario_id";

    public static final String SQL_VACIAR_FAVORITOS = "DELETE FROM FAVORITOS WHERE USUARIO_ID = :usuario_id";
}