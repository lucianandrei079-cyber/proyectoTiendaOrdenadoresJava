package com.lucian.tiendaordenador.RESTcontrollers;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lucian.tiendaordenador.model.Ordenador;
import com.lucian.tiendaordenador.servicios.ServicioOrdenadores;

@RestController
@RequestMapping("ordenadoresREST/")
public class OrdenadoresREST {
	@Autowired
	private ServicioOrdenadores servicioOrdenadores;

	@RequestMapping("obtener")
	public List<Map<String, Object>> obtener() {
		return servicioOrdenadores.obtenerOrdenadoresParaFormarJSON();
	}
}
