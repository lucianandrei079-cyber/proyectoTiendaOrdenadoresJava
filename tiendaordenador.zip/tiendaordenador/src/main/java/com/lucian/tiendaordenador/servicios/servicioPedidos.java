package com.lucian.tiendaordenador.servicios;

import java.util.List;

import com.lucian.tiendaordenador.RESTcontrollers.datos.ResumenPedido;
import com.lucian.tiendaordenador.model.Pedido;

public interface servicioPedidos {
	
	//gestion de administración
	List<Pedido> obtenerPedidos();
	
	Pedido obtenerPedidoPorId(int idPedido);
	
	void actualizarPedido(int idPedido, String estado);
	
	//operaciones ajax
	void procesarPaso1(String nombre, String direccion, String provincia, String telefono, String codigoPostal, String correo, int idUsuario);

	void procesarPaso2(String tarjeta, String numero, String titular, int idUsuario);

	void confirmarPedido(int idUsuario);

	ResumenPedido procesarPaso3(String comentario, int idUsuario);
	
}
