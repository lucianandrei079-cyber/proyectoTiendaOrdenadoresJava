package com.lucian.tiendaordenador.controllers.admin;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.lucian.tiendaordenador.model.Ordenador;
import com.lucian.tiendaordenador.servicios.ServicioCategorias;
import com.lucian.tiendaordenador.servicios.ServicioOrdenadores;

import jakarta.validation.Valid;

@Controller
@RequestMapping("admin/")
public class OrdenadoresController {

    @Autowired
    private ServicioOrdenadores servicioOrdenadores;
    
    @Autowired
    private ServicioCategorias servicioCategorias;

    @RequestMapping("editarOrdenador")
    public String editarOrdenador(@RequestParam("id") Long id, Model model) {
        Ordenador ordenador = servicioOrdenadores.obtenerOrdenadorPorId(id);
        ordenador.setIdCategoria(ordenador.getCategoria().getId());
        model.addAttribute("ordenadorEditar", ordenador);
        
        model.addAttribute("categorias", servicioCategorias.obtenerCategorias());
        
        
        return "admin/ordenadores_editar";
    }

    @RequestMapping("guardarCambiosOrdenador")
    public String guardarCambiosOrdenador(@ModelAttribute("ordenadorEditar") Ordenador ordenadorEditar, Model model) {
        procesarImagenes(ordenadorEditar);
        servicioOrdenadores.actualizarOrdenador(ordenadorEditar);
        return obtenerOrdenadores(model);
    }

    @RequestMapping("registrarOrdenador")
    public String registrarOrdenador(Model model) {
        model.addAttribute("nuevoOrdenador", new Ordenador());
        //vamos a meter las categorias en model para que le lleguen a la vista
        model.addAttribute("categorias", servicioCategorias.obtenerCategorias());
        
        return "admin/ordenadores_registro";
    }

    @RequestMapping("guardarOrdenador")
    public String guardarOrdenador(@ModelAttribute("nuevoOrdenador") @Valid Ordenador nuevoOrdenador, BindingResult resultadoValidaciones, Model model) {
    	if (resultadoValidaciones.hasErrors()) {
    		return "admin/ordenadores_registro";
    	}
        procesarImagenes(nuevoOrdenador);
        servicioOrdenadores.registrarOrdenador(nuevoOrdenador);
        return obtenerOrdenadores(model);
    }

    @RequestMapping("nuevoOrdenador")
    public String nuevoOrdenador(@ModelAttribute("nuevoOrdenador") Ordenador nuevoOrdenador, Model model) {
        servicioOrdenadores.registrarOrdenador(nuevoOrdenador);
        return obtenerOrdenadores(model);
    }

    @RequestMapping("obtenerOrdenadores")
    public String obtenerOrdenadores(Model model) {
        model.addAttribute("ordenadores", servicioOrdenadores.obtenerOrdenadores());
        return "admin/ordenadores";
    }

    @RequestMapping("borrarOrdenador")
    public String borrarOrdenador(@RequestParam("id") Long id, Model model) {
        servicioOrdenadores.borrarOrdenador(id);
        return obtenerOrdenadores(model);
    }

    // Método auxiliar para procesar imágenes
    private void procesarImagenes(Ordenador ordenador) {
        try {
            if (ordenador.getImagen() != null && !ordenador.getImagen().isEmpty()) {
                ordenador.setImagenPortada(ordenador.getImagen().getBytes());
            }
            if (ordenador.getImagen1() != null && !ordenador.getImagen1().isEmpty()) {
                ordenador.setImagenSecundaria1(ordenador.getImagen1().getBytes());
            }
            if (ordenador.getImagen2() != null && !ordenador.getImagen2().isEmpty()) {
                ordenador.setImagenSecundaria2(ordenador.getImagen2().getBytes());
            }
        } catch (IOException e) {
            e.printStackTrace(); 
        }
    }
}