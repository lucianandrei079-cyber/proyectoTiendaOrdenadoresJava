package com.lucian.tiendaordenador.interceptores;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

// Este interceptor se ejecuta antes de atender cualquier petición hacia /admin/

@Component
public class InterceptorAdmin implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {

        if (request.getRequestURI().contains("/admin/")) {
            System.out.println("Se ejecuta el interceptor de admin");
            System.out.println("Comprobando si el administrador está identificado en sesión...");

            // Verificar si llega el parámetro pass-admin
            if (request.getParameter("pass-admin") != null) {
                String passAdmin = request.getParameter("pass-admin");
                if (passAdmin.equals("123")) {
                    request.getSession().setAttribute("admin", "ok");
                }
            }

            // Redirigir si no está autenticado como admin
            Object adminAttr = request.getSession().getAttribute("admin");
            if (adminAttr == null || !adminAttr.equals("ok")) {
                response.sendRedirect("../loginAdmin");
                return false;
            }
        }

        return true;
    }
}
