package com.lucian.tiendaordenador.serviciosJPAImpl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.query.sql.internal.NativeQueryImpl;
import org.hibernate.transform.AliasToEntityMapResultTransformer;
import org.springframework.stereotype.Service;

import com.lucian.tiendaordenador.constantesSQL.ConstantesSQL;
import com.lucian.tiendaordenador.model.Categoria;
import com.lucian.tiendaordenador.model.Ordenador;
import com.lucian.tiendaordenador.servicios.ServicioOrdenadores;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;
import jakarta.persistence.TupleElement;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class ServicioOrdenadoresImpl implements ServicioOrdenadores {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public void registrarOrdenador(Ordenador ordenador) {
        try {
            if (ordenador.getImagen() != null && !ordenador.getImagen().isEmpty()) {
                ordenador.setImagenPortada(ordenador.getImagen().getBytes());
            }
            if (ordenador.getImagen1() != null && !ordenador.getImagen1().isEmpty()) {
                ordenador.setImagenSecundaria1(ordenador.getImagen1().getBytes());
            }
            if (ordenador.getImagen2() != null && !ordenador.getImagen2().isEmpty()) {
                ordenador.setImagenSecundaria2(ordenador.getImagen2().getBytes());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        //tenemos que asociar la categoria a nivel de base de datos
        //porque idCategoria tiene puesto @Transient
        Categoria categoria = entityManager.find(Categoria.class, ordenador.getIdCategoria());
        ordenador.setCategoria(categoria);
        
        entityManager.persist(ordenador);
    }

    @Override
    public List<Ordenador> obtenerOrdenadores() {
        return entityManager.createQuery("select o from Ordenador o order by o.id desc", Ordenador.class).getResultList();
    }

    @Override
    public void borrarOrdenador(long id) {
        //antes de borrar el producto debemos eliminar todas las referencias
    	//al mismo en el carrito y pedidos
    	entityManager.createNativeQuery("delete from carrito where ordenador_id = :id")
        		.setParameter("id", id)
        		.executeUpdate();
    	
    	entityManager.createNativeQuery("delete from producto_pedido where ordenador_id = :id")
        		.setParameter("id", id)
        		.executeUpdate();
    	
    	entityManager.createNativeQuery("delete from tabla_ordenadores where id = :id")
                     .setParameter("id", id)
                     .executeUpdate();
    }

    @Override
    public void actualizarOrdenador(Ordenador ordenadorFormEditar) {
        Ordenador ordenadorBD = entityManager.find(Ordenador.class, ordenadorFormEditar.getId());

        ordenadorBD.setNombre(ordenadorFormEditar.getNombre());
        ordenadorBD.setCpu(ordenadorFormEditar.getCpu());
        ordenadorBD.setGpu(ordenadorFormEditar.getGpu());
        ordenadorBD.setPlaca(ordenadorFormEditar.getPlaca());
        ordenadorBD.setPrecio(ordenadorFormEditar.getPrecio());
        ordenadorBD.setPcu(ordenadorFormEditar.getPcu());
        ordenadorBD.setRam(ordenadorFormEditar.getRam());
        ordenadorBD.setCaja(ordenadorFormEditar.getCaja());
        ordenadorBD.setMemoria(ordenadorFormEditar.getMemoria());
        ordenadorBD.setExtras(ordenadorFormEditar.getExtras());
        ordenadorBD.setDescripcion(ordenadorFormEditar.getDescripcion());

        try {
            if (ordenadorFormEditar.getImagen() != null && !ordenadorFormEditar.getImagen().isEmpty()) {
                ordenadorBD.setImagenPortada(ordenadorFormEditar.getImagen().getBytes());
            }
            if (ordenadorFormEditar.getImagen1() != null && !ordenadorFormEditar.getImagen1().isEmpty()) {
                ordenadorBD.setImagenSecundaria1(ordenadorFormEditar.getImagen1().getBytes());
            }
            if (ordenadorFormEditar.getImagen2() != null && !ordenadorFormEditar.getImagen2().isEmpty()) {
                ordenadorBD.setImagenSecundaria2(ordenadorFormEditar.getImagen2().getBytes());
            }
        } catch (IOException e) {
            System.out.println("No se pudo procesar alguna de las imágenes subidas");
            e.printStackTrace();
        }
        ordenadorBD.setCategoria(entityManager.find(Categoria.class, ordenadorFormEditar.getIdCategoria()));
        
        entityManager.merge(ordenadorBD);
    }

    @Override
    public Ordenador obtenerOrdenadorPorId(long id) {
        return entityManager.find(Ordenador.class, id);
    }

    @Override
    public List<Map<String, Object>> obtenerOrdenadoresParaFormarJSON() {
        Query query = entityManager.createNativeQuery(ConstantesSQL.SQL_OBTENER_ORDENADORES_PARA_JSON, Tuple.class);
        List<Tuple> tuples = query.getResultList();

        List<Map<String, Object>> resultado = new ArrayList<>();
        for (Tuple tuple : tuples) {
            Map<String, Object> fila = new HashMap<>();
            for (TupleElement<?> element : tuple.getElements()) {
                fila.put(element.getAlias(), tuple.get(element));
            }
            resultado.add(fila);
        }
        return resultado;
    }
}














