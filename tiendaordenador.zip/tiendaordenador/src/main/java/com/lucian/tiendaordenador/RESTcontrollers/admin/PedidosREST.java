package com.lucian.tiendaordenador.RESTcontrollers.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.lucian.tiendaordenador.servicios.servicioPedidos;

@RestController(value = "pedidosRESTadmin")
@RequestMapping("admin/pedidosREST/")
public class PedidosREST {
	
	@Autowired
	private servicioPedidos servicioPedidos;
	
	@RequestMapping("actualizarEstadoPedido")
	public String actualizarEstadoPedido(@RequestParam("id") Integer id, @RequestParam("estado") String estado) {
		servicioPedidos.actualizarPedido(id, estado);
		return "ok";
	}
}
