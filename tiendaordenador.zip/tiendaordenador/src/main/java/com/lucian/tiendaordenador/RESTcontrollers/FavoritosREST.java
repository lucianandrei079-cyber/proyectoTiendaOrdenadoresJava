package com.lucian.tiendaordenador.RESTcontrollers;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.lucian.tiendaordenador.servicios.ServicioFavoritos;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("FavoritosREST/")
public class FavoritosREST {
	@Autowired
	private ServicioFavoritos servicioFavoritos;
	
	@RequestMapping("obtenerFavoritos")
	public List<Map<String, Object>> obtenerFavoritos(HttpServletRequest request) {
		int idUsuario = 
				(int)request.getSession().getAttribute("usuario_id");
		
		return servicioFavoritos.obtenerProductosFavoritos(idUsuario);
	}
	
	@RequestMapping("añadirFavorito")
	public String añadirFavorito(@RequestParam("id") Integer id, HttpServletRequest request) {
		int idUsuario = 
				(int)request.getSession().getAttribute("usuario_id");
		servicioFavoritos.añadirFavorito(idUsuario, id);
		
		return "ok";
	}
	
	@RequestMapping("eliminarFavorito")
	public String eliminarFavorito(@RequestParam("id") Long id, HttpServletRequest request) {
		int idUsuario = 
				(int)request.getSession().getAttribute("usuario_id");
		servicioFavoritos.quitarProductoFavorito(idUsuario, id);
		return "ok";
	}
}
