package com.lucian.tiendaordenador.constantes;

public enum Estados {
	INCOMPLETO,
	TERMINADO,
	LISTO_PARA_ENVIAR,
	ENVIADO
	
}
