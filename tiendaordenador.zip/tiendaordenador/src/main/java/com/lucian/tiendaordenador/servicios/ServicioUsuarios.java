package com.lucian.tiendaordenador.servicios;

import java.util.List;

import com.lucian.tiendaordenador.model.Usuario;


public interface ServicioUsuarios {

	void registrarUsuario(Usuario usuario);
	
	List<Usuario> obtenerUsuarios();
	
	void borrarUsuario(int id);
	
	Usuario obtenerUsuarioPorId(int id);

	void actualizarUsuario(Usuario usuarioEditar);

	Usuario obtenerUsuarioPorEmailYpass(String email, String pass);

	Usuario obtenerUsuarioPorEmail(String email);
	
}
