package com.lucian.tiendaordenador.serviciosJPAImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.lucian.tiendaordenador.constantesSQL.ConstantesSQL;
import com.lucian.tiendaordenador.model.Favoritos;
import com.lucian.tiendaordenador.model.Ordenador;
import com.lucian.tiendaordenador.model.Usuario;
import com.lucian.tiendaordenador.servicios.ServicioFavoritos;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;
import jakarta.persistence.TupleElement;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class ServicioFavoritosImpl implements ServicioFavoritos {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public void añadirFavorito(int idUsuario, long idProducto) {
        Usuario usuario = entityManager.find(Usuario.class, idUsuario);
        Ordenador ordenador = entityManager.find(Ordenador.class, idProducto);

        // comprobar si ya existe en favoritos
        Query query = entityManager.createQuery(
            "SELECT f FROM Favoritos f WHERE f.usuario.id = :usuarioId AND f.ordenador.id = :ordenadorId"
        );
        query.setParameter("usuarioId", idUsuario);
        query.setParameter("ordenadorId", idProducto);

        List<Favoritos> existentes = query.getResultList();
        if (existentes.isEmpty()) {
            Favoritos favorito = new Favoritos();
            favorito.setUsuario(usuario);
            favorito.setOrdenador(ordenador);
            entityManager.persist(favorito);
        }
    }

    @Override
    public List<Map<String, Object>> obtenerProductosFavoritos(int idUsuario) {
        Query query = entityManager.createNativeQuery(
            ConstantesSQL.SQL_OBTENER_PRODUCTOS_FAVORITOS, Tuple.class
        );
        query.setParameter("usuario_id", idUsuario);

        List<Tuple> tuples = query.getResultList();
        List<Map<String, Object>> resultado = new ArrayList<>();

        for (Tuple tuple : tuples) {
            Map<String, Object> fila = new HashMap<>();
            for (TupleElement<?> element : tuple.getElements()) {
                fila.put(element.getAlias(), tuple.get(element));
            }
            resultado.add(fila);
        }
        return resultado;
    }

    @Override
    public void quitarProductoFavorito(int idUsuario, Long idOrdenador) {
        entityManager.createNativeQuery(ConstantesSQL.SQL_ELIMINAR_PRODUCTO_FAVORITO)
            .setParameter("usuario_id", idUsuario)
            .setParameter("ordenador_id", idOrdenador)
            .executeUpdate();
    }
}