package com.lucian.tiendaordenador.controllers.imagen;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.lucian.tiendaordenador.servicios.ServicioOrdenadores;

import jakarta.servlet.http.HttpServletResponse;

@Controller
public class MostrarImagenProducto {

	@Autowired
	private ServicioOrdenadores servicioOrdenadores;

	@RequestMapping("mostrar_imagen")
	public void mostrarImagen(@RequestParam("id") Long id, HttpServletResponse response) throws IOException {
		byte[] info = servicioOrdenadores.obtenerOrdenadorPorId(id).getImagenPortada();
		if (info == null) {
			return;
		}
		response.setContentType("image/jpeg");
		response.getOutputStream().write(info);
		response.getOutputStream().close();
	}

	@RequestMapping("mostrar_imagen1")
	public void mostrarImagen1(@RequestParam("id") Long id, HttpServletResponse response) throws IOException {
		byte[] info = servicioOrdenadores.obtenerOrdenadorPorId(id).getImagenSecundaria1();
		if (info == null) {
			return;
		}
		response.setContentType("image/jpeg");
		response.getOutputStream().write(info);
		response.getOutputStream().close();
	}

	@RequestMapping("mostrar_imagen2")
	public void mostrarImagen2(@RequestParam("id") Long id, HttpServletResponse response) throws IOException {
		byte[] info = servicioOrdenadores.obtenerOrdenadorPorId(id).getImagenSecundaria2();
		if (info == null) {
			return;
		}
		response.setContentType("image/jpeg");
		response.getOutputStream().write(info);
		response.getOutputStream().close();
	}
}
