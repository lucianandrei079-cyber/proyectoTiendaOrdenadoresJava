package com.lucian.tiendaordenador.servicios;

import java.util.List;

import com.lucian.tiendaordenador.model.Categoria;

public interface ServicioCategorias {
	
	List<Categoria> obtenerCategorias();
	
}
