package com.lucian.tiendaordenador.RESTcontrollers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lucian.tiendaordenador.RESTcontrollers.datos.ResumenPedido;
import com.lucian.tiendaordenador.servicios.servicioPedidos;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("pedidosREST/")
public class PedidosREST {
	@Autowired
	private servicioPedidos servicioPedidos;
	
	@RequestMapping("paso4")
	public String paso4(HttpServletRequest request) {
		int idUsuario = 
				(int)request.getSession().getAttribute("usuario_id");
		servicioPedidos.confirmarPedido(idUsuario);
		return "ok";
	}
	@RequestMapping("paso3")
	public ResumenPedido paso3 (String comentario, HttpServletRequest request) {
		int idUsuario = 
				(int)request.getSession().getAttribute("usuario_id");
		ResumenPedido resumen = servicioPedidos.procesarPaso3(comentario, idUsuario);
		return resumen;
	}
	
	
	@RequestMapping("paso2")
	public String paso2 (String tarjeta, String numero, String titular, HttpServletRequest request) {
		String respuesta = "";
		int idUsuario = 
				(int)request.getSession().getAttribute("usuario_id");
		servicioPedidos.procesarPaso2(tarjeta, numero, titular, idUsuario);
		respuesta = "ok";
		return respuesta;
	}
	
	@RequestMapping("paso1")
	public String paso1(String nombre, String direccion, String provincia,String telefono, String codigoPostal, String correo, HttpServletRequest request) {
		String respuesta = "";
		int idUsuario = 
				(int)request.getSession().getAttribute("usuario_id");
		servicioPedidos.procesarPaso1(nombre, direccion,provincia,telefono, codigoPostal, correo, idUsuario);
		respuesta = "ok";
		return respuesta;
	}
}
