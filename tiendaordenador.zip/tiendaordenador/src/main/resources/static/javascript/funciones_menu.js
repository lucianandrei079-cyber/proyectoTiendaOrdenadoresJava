
function checkout_paso_4(json){
	let html = Mustache.render(plantilla_checkout_4, json)
	$("#contenedor").html(html)
	$("#boton_confirmar_pedido").click(function(){
		$.post("pedidosREST/paso4").done(function(res){
			alert(res)
			if (res == "ok"){
				obtenerOrdenadores()
			}
		})
	})
}

function checkout_paso_3(){
	$("#contenedor").html(plantilla_checkout_3)
	$("#aceptar_paso_3").submit(function(e){
		e.preventDefault()
		comentario = $("#campo_comentario").val()
		$.post("pedidosREST/paso3", {
			comentario: comentario
		}).done(function(res){		
			checkout_paso_4(res)
			
		})
	})
}

function checkout_paso_2(){
	$("#contenedor").html(plantilla_checkout_2)
	$("#aceptar_paso_2").submit(function(e){
		e.preventDefault()
		tipo_tarjeta = $("#tipo_tarjeta").find(":selected").val()
		if(tipo_tarjeta == "0"){
			alert("seleccione un tipo de tarjeta")
			return
		}
		numero = $("#numero_tarjeta").val()
		titular = $("#titular_tarjeta").val()
		$.post("pedidosREST/paso2",{
			tarjeta : tipo_tarjeta,
			numero : numero,
			titular : titular
		}).done(function(res){
			//usar la plantilla de checkout paso3 y procesarla con el json recibido
			checkout_paso_3(res)
		})
	})
}

function checkout_paso_1(){
	nombre = $("#campo_nombre").val()
	direccion = $("#campo_direccion").val()
	provincia = $("#campo_provincia").val()
	telefono = $("#campo_telefono").val()
	codigoPostal = $("#campo_codigoPostal").val()
	correo = $("#campo_correo").val()
	alert("mandar la info insertada a pedidodsREST")
	$.post("pedidosREST/paso1",{
		nombre: nombre,
		direccion: direccion,
		provincia: provincia,
		telefono: telefono,
		codigoPostal: codigoPostal, 
		correo: correo
	}).done(function(res){
		alert(res)
		if(res == "ok"){
			alert("mostrar plantilla checkout2")
			checkout_paso_2()
		}
	})
}

function checkout_paso_0(){
	$("#contenedor").html(plantilla_checkout_1)
	$("#aceptar_paso_1").submit(function(e){
		e.preventDefault()
		checkout_paso_1()
	})
}

function mostrarCarrito(){
	if(nombre_login == ""){
		alert("tienes que identificarte para comprar productos");
		console.log("mostrarCarrito ejecutado");
	} else {
		$.get("carritoREST/obtener", function(r){
			if(r.length == 0){
				alert("aun no has agregado nada al carrito")
			}else {
				let html = Mustache.render(plantilla_carrito, r)
				$("#contenedor").html(html)
				$("#realizar_pedido").click(checkout_paso_0)
				
				//decir que hay que hacer cuando se haga click
				//en el enlace de borrar producto
				$(".enlace-borrar-producto-carrito").click(function(){
					if(! confirm("¿estas seguro?")){
						return
					}
					let idOrdenador = $(this).attr("id-ordenador")
					alert("mandar el id de ordenador " + idOrdenador + " a carritoREST para que lo borre del carrito")
					$.post("carritoREST/eliminar", {
						id : idOrdenador
					}).done(function(res){
						alert(res)
						if(res == "ok"){
							mostrarCarrito()
						}
					})
				})
			}
		});
	}
}


function comprar_producto(){
	if(nombre_login == ""){
		alert("tienes que identificarte para comprar productos")
	}else{
		var id_producto = $(this).attr("id-producto")
		alert("añadir producto de id: " + id_producto + " al carrito")
		
		$.post("carritoREST/agregarProducto", {
			id: id_producto,
			cantidad: 1
		}).done(function(res){
			alert(res)
		})
	}
	
}//end function

function obtenerOrdenadores(){
	$.get("ordenadoresREST/obtener", function(r){
		var ordenadores = r;
		console.log(ordenadores)
		var info = Mustache.render(plantilla_ordenadores, {XXX : "Hola desde mustache", array_ordenadores: ordenadores});
		$("#contenedor").html(info)
		$(".enlace_comprar_producto").click(comprar_producto)
		$(".checkbox_favorito").change(marcar_favorito);

	})
	$("#contenedor").html("cargando...");
}// end function

// function obtenerOrdenadores(){
//     $("#contenedor").html('<div class="loading">Cargando...</div>');
    
//     $.get("ServicioOrdenador", function(r){
//         var ordenadores = JSON.parse(r);
//         console.log(ordenadores);
//         var info = "";
        
//         for(i in ordenadores){
//             info += '<div class="computer-card">';
//             info += '<div class="computer-name">' + ordenadores[i].nombre + '</div>';
//             info += '<div class="computer-spec"><strong>CPU:</strong> ' + ordenadores[i].cpu + '</div>';
//             info += '<div class="computer-spec"><strong>GPU:</strong> ' + ordenadores[i].gpu + '</div>';
//             info += '<div class="computer-spec"><strong>Placa:</strong> ' + ordenadores[i].placa + '</div>';
//             info += '<div class="computer-spec"><strong>PCU:</strong> ' + ordenadores[i].pcu + '</div>';
//             info += '<div class="computer-spec"><strong>RAM:</strong> ' + ordenadores[i].ram + '</div>';
//             info += '<div class="computer-spec"><strong>Caja:</strong> ' + ordenadores[i].caja + '</div>';
//             info += '<div class="computer-spec"><strong>Memoria:</strong> ' + ordenadores[i].memoria + '</div>';
//             info += '<div class="computer-spec"><strong>Extras:</strong> ' + ordenadores[i].extras + '</div>';
//             if(ordenadores[i].descripcion) {
//                 info += '<div class="computer-description">' + ordenadores[i].descripcion + '</div>';
//             }
//             info += '</div>';
//         }
//         $("#contenedor").html(info);
//     });
// }

function mostrarLogin(){
    $("#contenedor").html(plantilla_login);
    $("#form_login").submit(function(e){
		e.preventDefault()
		var email = $("#email").val()
		var pass = $("#pass").val()
		$.post("usuariosREST/login", {
			email: email,
			pass: pass
		}).done(function(res){
			var parte1 = res.split(",")[0]
			var parte2 = res.split(",")[1]
			if(parte1 == "ok"){
				alert("bienvenido " + parte2 + " ya puedes comprar")
				nombre_login = parte2
				$("#login_usuario").html("hola " + parte2)
			}else{
				alert(res)
			}
		})//end done
    })//end submit
}//end function

function mostrarRegistro(){
	$("#contenedor").html(plantilla_registro)
	$("#form_registro").submit(function(e){
		e.preventDefault()	
		var nombre = $("#nombre").val()
		var apellidos = $("#apellidos").val()
		var telefono = $("#telefono").val()
		var email = $("#email").val()
		var pass = $("#pass").val()
		$.post("usuariosREST/registrar",{
			nombre: nombre,
			apellidos: apellidos,
			telefono: telefono,
			email: email,
			pass: pass
		}).done(function(res){
			alert(res)
		})//end done
	})//end submit
}//end funcion principal

function mostrarFavoritos(){
    if(nombre_login == ""){
        alert("tienes que identificarte para ver tus favoritos");
    } else {
        $.get("FavoritosREST/obtenerFavoritos", function(r){
            if(r.length == 0){
                alert("aún no has agregado nada a favoritos");
            } else {
                let html = Mustache.render(plantilla_favoritos, { array_favoritos: r });
                $("#contenedor").html(html);

                // Acción para borrar de favoritos
                $(".enlace-borrar-producto-favorito").click(function(){
                    if(!confirm("¿Estás seguro de quitar este producto de favoritos?")){
                        return;
                    }
                    let idOrdenador = $(this).attr("id-ordenador");
                    $.post("FavoritosREST/eliminarFavorito", { id: idOrdenador })
                        .done(function(res){
                            alert(res);
                            if(res == "ok"){
                                mostrarFavoritos(); // recargar lista de favoritos
                            }
                        });
                });

                // Acción para añadir al carrito desde favoritos
                $(".enlace_comprar_producto").click(comprar_producto);

                // Acción para marcar/desmarcar favoritos desde la lista
                $(".checkbox_favorito").change(marcar_favorito);
            }
        });
    }
}

// Acción de marcar producto como favorito
function marcar_favorito(){
    if(nombre_login == ""){
        alert("tienes que identificarte para marcar favoritos");
        $(this).prop("checked", false); // desmarcar si no está logueado
        return; 
    } 

    var id_producto = $(this).attr("id-producto");
    var marcado = $(this).is(":checked");

    if(marcado){
        $.post("FavoritosREST/añadirFavorito", { id: id_producto })
            .done(function(res){ alert(res); });
    } else {
        $.post("FavoritosREST/eliminarFavorito", { id: id_producto })
            .done(function(res){ alert(res); });
    }
}

$("#enlace_carrito").click(mostrarCarrito);
$("#enlace_favoritos").click(mostrarFavoritos)
$("#enlace_productos").click(obtenerOrdenadores);
$("#enlace_identificarme").click(mostrarLogin);
$("#enlace_registrarme").click(mostrarRegistro);
