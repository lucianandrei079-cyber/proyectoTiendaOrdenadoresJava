//variables globales a usar en la parte cliente

var idioma = ""
var nombre_login = ""

var plantilla_registro = "";
var plantilla_login = "";
var plantilla_ordenadores = "";
var plantilla_carrito = "";
var plantilla_favoritos = "";
var plantilla_checkout_1 = "";
var plantilla_checkout_2 = "";
var plantilla_checkout_3 = "";
var plantilla_checkout_4 = "";

