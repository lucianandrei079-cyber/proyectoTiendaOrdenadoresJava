$.get("plantillas_mustache" + idioma + "/registrarme.html", function(r){
	plantilla_registro = r;
})

$.get("plantillas_mustache" + idioma + "/login.html", function(r){
	plantilla_login = r;
})

$.get("plantillas_mustache" + idioma + "/ordenadores.html", function(r){
	plantilla_ordenadores = r;
})

$.get("plantillas_mustache" + idioma + "/carrito.html", function(r){
	plantilla_carrito = r;
})

$.get("plantillas_mustache" + idioma + "/favoritos.html", function(r){
	plantilla_favoritos = r;
})

$.get("plantillas_mustache" + idioma + "/checkout_1.html", function(r){
	plantilla_checkout_1 = r;
})

$.get("plantillas_mustache" + idioma + "/checkout_2.html", function(r){
	plantilla_checkout_2 = r;
})

$.get("plantillas_mustache" + idioma + "/checkout_3.html", function(r){
	plantilla_checkout_3 = r;
})
$.get("plantillas_mustache" + idioma + "/checkout_4.html", function(r){
	plantilla_checkout_4 = r;
})